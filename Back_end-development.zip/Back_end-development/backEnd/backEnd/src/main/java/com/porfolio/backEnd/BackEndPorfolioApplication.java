package com.porfolio.backEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackEndPorfolioApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackEndPorfolioApplication.class, args);
	}

}
