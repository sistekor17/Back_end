package com.porfolioweb.backEndPorfolio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackEndPorfolioApplicationTests {

	@Test
	void contextLoads() {
	}

}
